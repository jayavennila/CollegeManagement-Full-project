package com.example.demo.CollegeManagementSystemEx.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "students")
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "first_name")
	private String FirstName;

	@Column(name = "last_name")
	private String LastName;
	
	@Column(name = "roll_no")
	private String RollNo;
	
	@Column(name = "department")
	private String Department;
	
	@Column(name = "mobile_no")
	private long  MobileNo;
public Student() {
		
	}
public Student(String FirstName, String LastName, String RollNo, String Department, long MobileNo) {
	super();
	this.FirstName = FirstName;
	this.LastName = LastName;
	this.RollNo = RollNo;
	this.Department = Department;
	this.MobileNo = MobileNo;
}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		this.FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		this.LastName = lastName;
	}

	public String getRollNo() {
		return RollNo;
	}

	public void setRollNo(String rollNo) {
		RollNo = rollNo;
	}

	public String getDepartment() {
		return Department;
	}

	public void setDepartment(String department) {
		this.Department = department;
	}

	public long getMobileNo() {
		return MobileNo;
	}

	public void setMobileNo(long mobileNo) {
		MobileNo = mobileNo;
	}
}
