export class Student {
    id: number;
    FirstName: string;
    LastName: string;
    RollNo: string;
    Department: string;
    MobileNo: number;
}
